<?php

namespace App\Models;

use CodeIgniter\Model;

class Data_model extends Model{

    protected $table = "data";

     public function getData()
    {
        
         $login = $this->table($this->table)
                    ->get()
                    ->getResult();
         return $login;
    }
}